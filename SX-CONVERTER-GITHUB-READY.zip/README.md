# SX CONVERTER

Real backend-powered file conversion platform for six public formats: PDF, HTML, APK, ZIP, DOCX and TXT.

## Architecture
- Frontend: `index.html` + `public/css/style.css` + `public/js/app.js`
- Backend: Node.js + Express
- Real document processing: LibreOffice + Poppler utilities
- Real ZIP/package inspection: JSZip
- Real PDF validation: pdf-lib
- Real DOCX generation/validation
- Real HTML/TXT document conversion
- Real HTML/ZIP/TXT/DOCX/PDF-to-WebView APK builds through Android SDK + Gradle
- Uploaded APKs are never executed
- Archive extraction is path-traversal protected and size-limited

## Run locally
1. Install Node.js 22+, LibreOffice, Poppler (`pdftotext`, `pdftohtml`), Java 17, Android SDK and Gradle 8.10.2 for APK builds.
2. `npm install`
3. Copy `.env.example` to `.env` and adjust values.
4. `npm start`
5. Open `http://localhost:10000`

## Docker / Render
The supplied Dockerfile installs Node.js runtime dependencies, LibreOffice, Poppler, Java 17, Android SDK platform/build tools and Gradle. Render should use Docker runtime and the repository's `Dockerfile`.

## Important truthfulness rule
The backend never claims a conversion completed unless a real output was generated and structurally validated. Some transformations of arbitrary native APKs are inherently impossible; those return `CONVERSION FAILED` rather than fabricated source code.

## GitHub
The repository is designed as a normal Git repository. If uploading from GitHub's web UI, upload the project ZIP and use a GitHub Actions workflow to extract it into the repository root before connecting the repository to Render.
