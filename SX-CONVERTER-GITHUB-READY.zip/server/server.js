const express=require('express');
const cors=require('cors');
const path=require('path');
const fs=require('fs-extra');
const {v4:uuid}=require('uuid');
const multer=require('multer');
const rateLimit=require('express-rate-limit');
const JSZip=require('jszip');
const {PDFDocument}=require('pdf-lib');
const {convert}=require('./services/conversionService');

const app=express();
const PORT=Number(process.env.PORT||10000),HOST=process.env.HOST||'0.0.0.0';
const MAX_MB=Math.max(1,Number(process.env.MAX_FILE_SIZE_MB||100));
const DATA=path.resolve(process.env.DATA_DIR||'./data');
const uploads=path.join(DATA,'uploads'),outputs=path.join(DATA,'outputs'),tmp=path.join(DATA,'tmp');
for(const d of [uploads,outputs,tmp])fs.ensureDirSync(d);
const FORMATS=['PDF','HTML','APK','ZIP','DOCX','TXT'];
const EXT_MIME={'.pdf':'application/pdf','.html':'text/html','.htm':'text/html','.apk':'application/vnd.android.package-archive','.zip':'application/zip','.docx':'application/vnd.openxmlformats-officedocument.wordprocessingml.document','.txt':'text/plain'};
const jobs=new Map();
const limiter=rateLimit({windowMs:60*1000,max:Number(process.env.RATE_LIMIT_PER_MINUTE||30),standardHeaders:true,legacyHeaders:false});
app.set('trust proxy',1);app.use(cors({origin:process.env.CORS_ORIGIN||'*'}));app.use(express.json({limit:'1mb'}));app.use('/api',limiter);app.use(express.static(path.join(__dirname,'..')));
function sanitizeFilename(s){const b=path.basename(String(s||'file'));const c=b.replace(/[^\w.\-() ]/g,'_').replace(/^\.+/,'_').slice(0,160);return c||'file'}
function safeChild(root,child){const a=path.resolve(root),b=path.resolve(child);return b!==a&&b.startsWith(a+path.sep)}
function mime(name){return EXT_MIME[path.extname(name).toLowerCase()]||'application/octet-stream'}
async function readHead(p,n=16){const h=Buffer.alloc(n);const fh=await fs.open(p,'r');try{const {bytesRead}=await fh.read(h,0,n,0);return h.subarray(0,bytesRead)}finally{await fh.close()}}
async function validateInput(p,fmt){const st=await fs.stat(p);if(!st.isFile()||st.size<=0)throw Error('INVALID FILE');const h=await readHead(p,16);
 if(fmt==='PDF'&&!h.toString('ascii',0,5).startsWith('%PDF-'))throw Error('INVALID FILE');
 if((fmt==='ZIP'||fmt==='APK'||fmt==='DOCX')&&!(h[0]===0x50&&h[1]===0x4b))throw Error('INVALID FILE');
 if(fmt==='HTML'){const s=(await fs.readFile(p,'utf8')).slice(0,1024*1024);if(!/<(?:!doctype\s+html|html[\s>]|body[\s>])/i.test(s))throw Error('INVALID FILE')}
 if(fmt==='TXT'){const b=await fs.readFile(p);if(b.includes(0))throw Error('INVALID FILE')}
 if(fmt==='DOCX'){const z=await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true});if(!z.files['[Content_Types].xml']||!z.files['word/document.xml'])throw Error('INVALID FILE')}
 if(fmt==='APK'){const z=await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true});if(!z.files['AndroidManifest.xml'])throw Error('INVALID FILE')}
 if(fmt==='ZIP'){await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true})}
}
async function validateOutput(p,fmt){if(!await fs.pathExists(p))throw Error('OUTPUT VALIDATION FAILED');const st=await fs.stat(p);if(!st.isFile()||st.size<=0)throw Error('OUTPUT VALIDATION FAILED');const h=await readHead(p,16);
 if(fmt==='PDF'){if(!h.toString('ascii',0,5).startsWith('%PDF-'))throw Error('OUTPUT VALIDATION FAILED');await PDFDocument.load(await fs.readFile(p))}
 else if(fmt==='HTML'){const s=await fs.readFile(p,'utf8');if(!/<html[\s>]/i.test(s))throw Error('OUTPUT VALIDATION FAILED')}
 else if(fmt==='TXT'){await fs.readFile(p,'utf8')}
 else if(fmt==='ZIP'){await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true})}
 else if(fmt==='DOCX'){const z=await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true});if(!z.files['[Content_Types].xml']||!z.files['word/document.xml'])throw Error('OUTPUT VALIDATION FAILED')}
 else if(fmt==='APK'){const z=await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true});if(!z.files['AndroidManifest.xml']||!z.files['classes.dex'])throw Error('OUTPUT VALIDATION FAILED')}
}
const upload=multer({dest:uploads,limits:{fileSize:MAX_MB*1024*1024,files:1},fileFilter:(req,file,cb)=>{if(!file.originalname||String(file.originalname).length>180)return cb(new Error('INVALID FILE'));cb(null,true)}});
app.get('/api/health',(req,res)=>res.json({ok:true,name:'SX CONVERTER',formats:FORMATS}));
app.get('/api/formats',(req,res)=>res.json({formats:FORMATS}));
app.post('/api/upload',upload.single('file'),async(req,res)=>{try{if(!req.file)return res.status(400).json({error:'INVALID FILE'});const id=uuid(),name=sanitizeFilename(req.file.originalname),target=path.join(uploads,`${id}__${name}`);if(!safeChild(uploads,target))throw Error('INVALID FILE');await fs.move(req.file.path,target,{overwrite:true});const st=await fs.stat(target);res.json({fileId:id,originalName:name,size:st.size,detectedMime:mime(name)})}catch(e){if(req.file?.path)await fs.remove(req.file.path).catch(()=>{});res.status(400).json({error:e.message||'INVALID FILE'})}});
app.post('/api/convert',async(req,res)=>{const {fileId,inputFormat,outputFormat}=req.body||{};if(!fileId||!FORMATS.includes(inputFormat)||!FORMATS.includes(outputFormat))return res.status(400).json({error:'INVALID FILE'});if(!/^[0-9a-f-]{20,80}$/i.test(String(fileId)))return res.status(400).json({error:'INVALID FILE'});if(inputFormat===outputFormat)return res.status(400).json({error:'Input and output formats must be different.'});const files=await fs.readdir(uploads);const name=files.find(x=>x.startsWith(`${fileId}__`));if(!name)return res.status(404).json({error:'Uploaded file not found.'});const input=path.join(uploads,name);if(!safeChild(uploads,input))return res.status(400).json({error:'INVALID FILE'});const job={jobId:uuid(),fileId,inputFormat,outputFormat,status:'QUEUED',progress:0,message:'Queued',outputPath:null,outputName:null,error:null};jobs.set(job.jobId,job);res.json({jobId:job.jobId,status:job.status});setImmediate(()=>runJob(job,input))});
async function runJob(job,input){job.status='PROCESSING';job.progress=8;job.message='Validating input...';try{await validateInput(input,job.inputFormat);job.progress=15;job.message='Running conversion engine...';const r=await convert({job,inputPath:input,outputDir:outputs,tmpDir:tmp});await validateOutput(r.outputPath,job.outputFormat);job.outputPath=r.outputPath;job.outputName=sanitizeFilename(r.outputName);job.status='COMPLETED';job.progress=100;job.message='Conversion complete'}catch(e){job.status='FAILED';job.progress=0;job.error=`CONVERSION FAILED: ${e.message||'Processing error.'}`}finally{await fs.remove(input).catch(()=>{});await fs.remove(path.join(tmp,job.jobId)).catch(()=>{})}}
app.get('/api/conversion/:id',(req,res)=>{const j=jobs.get(req.params.id);if(!j)return res.status(404).json({error:'SERVER ERROR'});res.json({jobId:j.jobId,status:j.status,progress:j.progress,message:j.message,error:j.error,outputName:j.outputName})});
app.get('/api/download/:id',async(req,res)=>{const j=jobs.get(req.params.id);if(!j||j.status!=='COMPLETED'||!j.outputPath)return res.status(404).json({error:'Output not available.'});if(!safeChild(outputs,j.outputPath)||!await fs.pathExists(j.outputPath))return res.status(404).json({error:'Output not available.'});res.download(j.outputPath,sanitizeFilename(j.outputName))});
app.delete('/api/conversion/:id',async(req,res)=>{const j=jobs.get(req.params.id);if(j?.outputPath&&safeChild(outputs,j.outputPath))await fs.remove(j.outputPath).catch(()=>{});jobs.delete(req.params.id);res.json({ok:true})});
app.use((err,req,res,next)=>{if(err instanceof multer.MulterError)return res.status(413).json({error:'FILE TOO LARGE'});res.status(400).json({error:err.message||'SERVER ERROR'})});
app.listen(PORT,HOST,()=>console.log(`SX CONVERTER listening on ${HOST}:${PORT}`));
