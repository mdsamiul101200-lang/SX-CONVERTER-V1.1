const path=require('path');
const fs=require('fs-extra');
const {execFile}=require('child_process');
const {promisify}=require('util');
const exec=promisify(execFile);
const {PDFDocument}=require('pdf-lib');
const JSZip=require('jszip');
const {Document,Packer,Paragraph}=require('docx');

const EXT={PDF:'pdf',HTML:'html',APK:'apk',ZIP:'zip',DOCX:'docx',TXT:'txt'};
const FORMATS=Object.keys(EXT);
const timeout=()=>Number(process.env.JOB_TIMEOUT_MS||300000);
async function command(name,args,options={}){return exec(name,args,{timeout:timeout(),maxBuffer:16*1024*1024,...options})}
function safeName(s){return String(s).replace(/[^\w.\-]+/g,'_').slice(0,120)}
function htmlText(s){return s.replace(/<script[\s\S]*?<\/script>/gi,'').replace(/<style[\s\S]*?<\/style>/gi,'').replace(/<[^>]+>/g,' ').replace(/\s+/g,' ').trim()}
function esc(s){return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;')}
function done(out,job){job.progress=96;job.message='Validating output...';return {outputPath:out,outputName:`SX-CONVERTER-${job.jobId}.${EXT[job.outputFormat]}`}}

async function convert({job,inputPath,outputDir,tmpDir}){
  const out=path.join(outputDir,`sx_${job.jobId}.${EXT[job.outputFormat]}`), work=path.join(tmpDir,job.jobId);
  await fs.ensureDir(work); const i=job.inputFormat,o=job.outputFormat; job.progress=20; job.message=`Preparing ${i} → ${o}...`;
  if(!FORMATS.includes(i)||!FORMATS.includes(o))throw Error('Unsupported format.');
  if(i===o)return sameFormat(inputPath,out,job);

  const registry={
    HTML:{TXT:htmlToTxt,PDF:htmlToPdf,DOCX:htmlToDocx,ZIP:(a,b,c,j)=>webToZip(a,b,c,j),APK:buildApkFromHtml},
    TXT:{HTML:txtToHtml,PDF:txtToPdf,DOCX:txtToDocx,ZIP:fileToZip,APK:buildApkFromTxt},
    DOCX:{TXT:docxToTxt,HTML:officeToHtml,PDF:officeToPdf,ZIP:fileToZip,APK:buildApkFromDocx},
    PDF:{TXT:pdfToTxt,HTML:pdfToHtml,DOCX:pdfToDocx,ZIP:fileToZip,APK:buildApkFromPdf},
    ZIP:{HTML:zipToHtml,PDF:zipToPdf,DOCX:zipToDocx,TXT:zipToTxt,APK:buildApkFromZip},
    APK:{ZIP:apkToZip,HTML:apkToHtml,PDF:apkToPdf,DOCX:apkToDocx,TXT:apkToTxt}
  };
  const fn=registry[i]?.[o]; if(!fn)throw Error(`No genuine conversion pipeline exists for ${i} → ${o}.`);
  return fn(inputPath,out,work,job);
}

async function sameFormat(input,out,job){
  // Legitimate processing: validate/normalize the package without pretending a different format was created.
  if(job.inputFormat==='PDF'){const d=await PDFDocument.load(await fs.readFile(input));await fs.writeFile(out,await d.save());return done(out,job)}
  if(job.inputFormat==='ZIP'||job.inputFormat==='APK'){await fs.copy(input,out);return done(out,job)}
  if(job.inputFormat==='TXT'){const s=await fs.readFile(input,'utf8');await fs.writeFile(out,s,'utf8');return done(out,job)}
  if(job.inputFormat==='HTML'){const s=await fs.readFile(input,'utf8');if(!/<html[\s>]/i.test(s))throw Error('Invalid HTML.');await fs.writeFile(out,s);return done(out,job)}
  if(job.inputFormat==='DOCX'){await validateDocx(input);await fs.copy(input,out);return done(out,job)}
}
async function htmlToTxt(i,o,j){const t=htmlText(await fs.readFile(i,'utf8'));if(!t)throw Error('HTML contains no recoverable text.');await fs.writeFile(o,t);return done(o,j)}
async function txtToHtml(i,o,j){const s=await fs.readFile(i,'utf8');await fs.writeFile(o,`<!doctype html><html><head><meta charset="utf-8"><title>SX CONVERTER</title></head><body><pre>${esc(s)}</pre></body></html>`);return done(o,j)}
async function txtToDocx(i,o,j){const s=await fs.readFile(i,'utf8');const d=new Document({sections:[{children:s.split(/\r?\n/).map(x=>new Paragraph(x))}]});await fs.writeFile(o,await Packer.toBuffer(d));return done(o,j)}
async function htmlToDocx(i,o,j){const t=htmlText(await fs.readFile(i,'utf8'));if(!t)throw Error('HTML contains no recoverable text.');return txtBufferToDocx(t,o,j)}
async function txtBufferToDocx(s,o,j){const d=new Document({sections:[{children:s.split(/\r?\n/).map(x=>new Paragraph(x))}]});await fs.writeFile(o,await Packer.toBuffer(d));return done(o,j)}
async function docxToTxt(i,o,j){return office(i,o,j,'txt:Text')}
async function officeToPdf(i,o,j){return office(i,o,j,'pdf')}
async function officeToHtml(i,o,j){return office(i,o,j,'html')}
async function office(input,out,job,filter){const dir=path.join(path.dirname(out),`${job.jobId}_office`);await fs.ensureDir(dir);await command('libreoffice',['--headless','--convert-to',filter,'--outdir',dir,input]);const ext=filter.startsWith('txt')?'txt':filter.startsWith('pdf')?'pdf':'html';const f=(await fs.readdir(dir)).find(x=>x.toLowerCase().endsWith('.'+ext));if(!f)throw Error('Document conversion engine produced no output.');await fs.copy(path.join(dir,f),out);return done(out,job)}
async function htmlToPdf(i,o,j){return office(i,o,j,'pdf')}
async function txtToPdf(i,o,j){return office(i,o,j,'pdf')}
async function pdfToTxt(i,o,j){await command('pdftotext',[i,o]);return done(o,j)}
async function pdfToHtml(i,o,j){const dir=path.join(path.dirname(o),`${j.jobId}_pdfhtml`);await fs.ensureDir(dir);await command('pdftohtml',['-s','-noframes','-enc','UTF-8',i,path.join(dir,'document')]);const f=(await fs.readdir(dir)).find(x=>x.endsWith('.html'));if(!f)throw Error('PDF-to-HTML engine produced no HTML.');await fs.copy(path.join(dir,f),o);return done(o,j)}
async function pdfToDocx(i,o,j){const dir=path.join(path.dirname(o),`${j.jobId}_pdftxt`);await fs.ensureDir(dir);const txt=path.join(dir,'document.txt');await command('pdftotext',[i,txt]);const s=await fs.readFile(txt,'utf8');return txtBufferToDocx(s,o,j)}
async function fileToZip(i,o,w,j){const z=new JSZip();z.file(path.basename(i),await fs.readFile(i));await fs.writeFile(o,await z.generateAsync({type:'nodebuffer',compression:'DEFLATE'}));return done(o,j)}
async function webToZip(i,o,w,j){const z=new JSZip();z.file('index.html',await fs.readFile(i,'utf8'));await fs.writeFile(o,await z.generateAsync({type:'nodebuffer',compression:'DEFLATE'}));return done(o,j)}
async function safeUnzip(input,dir){const zip=await JSZip.loadAsync(await fs.readFile(input),{checkCRC32:true});let total=0,count=0;for(const [name,e] of Object.entries(zip.files)){if(++count>5000)throw Error('Archive contains too many entries.');const n=path.posix.normalize(name.replace(/\\/g,'/'));if(n.startsWith('../')||n.startsWith('/')||n.includes('/../'))throw Error('Unsafe archive path.');if(e.dir)continue;const b=await e.async('nodebuffer');total+=b.length;if(total>300*1024*1024)throw Error('Archive expands beyond safety limit.');const target=path.join(dir,n);await fs.ensureDir(path.dirname(target));await fs.writeFile(target,b)}}
function findFile(dir,tests){let hit=null;function walk(d){if(hit)return;for(const n of fs.readdirSync(d)){const p=path.join(d,n),s=fs.statSync(p);if(s.isDirectory())walk(p);else if(tests.some(t=>t(n))){hit=p;return}}}walk(dir);return hit}
const findHtml=d=>findFile(d,[n=>n.toLowerCase()==='index.html',n=>n.toLowerCase().endsWith('.html')]);
async function zipToHtml(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(!h)throw Error('ZIP contains no recoverable HTML.');await fs.copy(h,o);return done(o,j)}
async function zipToTxt(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(h)return htmlToTxt(h,o,j);const t=findFile(w,[n=>n.toLowerCase().endsWith('.txt')]);if(!t)throw Error('ZIP contains no recoverable text.');await fs.copy(t,o);return done(o,j)}
async function zipToPdf(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(h)return htmlToPdf(h,o,j);const t=findFile(w,[n=>n.toLowerCase().endsWith('.txt')]);if(t)return txtToPdf(t,o,j);const d=findFile(w,[n=>n.toLowerCase().endsWith('.docx')]);if(d)return officeToPdf(d,o,j);throw Error('ZIP contains no convertible document/web content.')}
async function zipToDocx(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(h)return htmlToDocx(h,o,j);const t=findFile(w,[n=>n.toLowerCase().endsWith('.txt')]);if(t)return txtToDocx(t,o,j);const d=findFile(w,[n=>n.toLowerCase().endsWith('.docx')]);if(d){await validateDocx(d);await fs.copy(d,o);return done(o,j)}throw Error('ZIP contains no convertible document/web content.')}
async function apkToZip(i,o,w,j){return fileToZip(i,o,w,j)}
async function apkToHtml(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(!h)throw Error('APK contains no recoverable HTML/web asset.');await fs.copy(h,o);return done(o,j)}
async function apkToTxt(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(h)return htmlToTxt(h,o,j);const t=findFile(w,[n=>n.toLowerCase().endsWith('.txt')]);if(!t)throw Error('APK contains no recoverable text asset.');await fs.copy(t,o);return done(o,j)}
async function apkToPdf(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(h)return htmlToPdf(h,o,j);const t=findFile(w,[n=>n.toLowerCase().endsWith('.txt')]);if(t)return txtToPdf(t,o,j);throw Error('APK contains no recoverable document/web content.')}
async function apkToDocx(i,o,w,j){await safeUnzip(i,w);const h=findHtml(w);if(h)return htmlToDocx(h,o,j);const t=findFile(w,[n=>n.toLowerCase().endsWith('.txt')]);if(t)return txtToDocx(t,o,j);throw Error('APK contains no recoverable document/web content.')}
async function buildApkFromHtml(i,o,w,j){const site=path.join(w,'site');await fs.ensureDir(site);const s=await fs.readFile(i,'utf8');if(!/<html[\s>]/i.test(s))throw Error('Input is not recognizable HTML.');await fs.writeFile(path.join(site,'index.html'),s);return buildWebViewApk(site,'index.html',o,w,j)}
async function buildApkFromTxt(i,o,w,j){const site=path.join(w,'site');await fs.ensureDir(site);const s=await fs.readFile(i,'utf8');await fs.writeFile(path.join(site,'index.html'),`<!doctype html><html><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>SX CONVERTER</title></head><body><pre>${esc(s)}</pre></body></html>`);return buildWebViewApk(site,'index.html',o,w,j)}
async function buildApkFromDocx(i,o,w,j){const dir=path.join(w,'docxhtml');await fs.ensureDir(dir);await officeToHtml(i,path.join(dir,'document.html'),j);return buildApkFromHtml(path.join(dir,'document.html'),o,w,j)}
async function buildApkFromPdf(i,o,w,j){const dir=path.join(w,'pdfhtml');await fs.ensureDir(dir);const html=path.join(dir,'document.html');await pdfToHtml(i,html,j);return buildApkFromHtml(html,o,w,j)}
async function buildApkFromZip(i,o,w,j){const site=path.join(w,'site');await safeUnzip(i,site);const h=findHtml(site);if(!h)throw Error('ZIP contains no recoverable HTML.');const rel=path.relative(site,h).split(path.sep).join('/');return buildWebViewApk(site,rel,o,w,j)}
async function buildWebViewApk(site,entry,out,w,j){const p=path.join(w,'android');await fs.ensureDir(path.join(p,'app/src/main/assets'));await fs.ensureDir(path.join(p,'app/src/main/java/com/sxconverter/app'));await fs.ensureDir(path.join(p,'app/src/main/res/values'));
await fs.writeFile(path.join(p,'settings.gradle'),`pluginManagement { repositories { google(); mavenCentral(); gradlePluginPortal() } }\ndependencyResolutionManagement { repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS); repositories { google(); mavenCentral() } }\nrootProject.name='SXConverterBuild'\ninclude ':app'`);
await fs.writeFile(path.join(p,'build.gradle'),`plugins { id 'com.android.application' version '8.6.1' apply false }`);
await fs.writeFile(path.join(p,'app/build.gradle'),`plugins { id 'com.android.application' }\nandroid { namespace 'com.sxconverter.app'; compileSdk 35; defaultConfig { applicationId 'com.sxconverter.generated'; minSdk 23; targetSdk 35; versionCode 1; versionName '1.0' } }`);
await fs.writeFile(path.join(p,'app/src/main/AndroidManifest.xml'),`<manifest xmlns:android="http://schemas.android.com/apk/res/android"><uses-permission android:name="android.permission.INTERNET"/><application android:theme="@style/AppTheme" android:label="SX CONVERTER"><activity android:name=".MainActivity" android:exported="true"><intent-filter><action android:name="android.intent.action.MAIN"/><category android:name="android.intent.category.LAUNCHER"/></intent-filter></activity></application></manifest>`);
await fs.writeFile(path.join(p,'app/src/main/res/values/styles.xml'),`<resources><style name="AppTheme" parent="android:style/Theme.Material.Light.NoActionBar"><item name="android:fontFamily">sans</item><item name="android:colorAccent">#35C8FF</item></style></resources>`);
const java=`package com.sxconverter.app; import android.app.Activity; import android.os.Bundle; import android.webkit.WebView; import android.webkit.WebSettings; public class MainActivity extends Activity { public void onCreate(Bundle b){super.onCreate(b); WebView w=new WebView(this); WebSettings s=w.getSettings(); s.setJavaScriptEnabled(true); s.setDomStorageEnabled(true); s.setAllowFileAccess(true); w.loadUrl("file:///android_asset/${entry.replace(/"/g,'')}"); setContentView(w);} }`;
await fs.writeFile(path.join(p,'app/src/main/java/com/sxconverter/app/MainActivity.java'),java);await fs.copy(site,path.join(p,'app/src/main/assets'));j.progress=65;j.message='Building genuine Android APK...';await command('gradle',['--no-daemon','--stacktrace','assembleDebug'],{cwd:p});const apk=path.join(p,'app/build/outputs/apk/debug/app-debug.apk');if(!fs.existsSync(apk))throw Error('Android build produced no APK.');await validateApk(apk);await fs.copy(apk,out);return done(out,j)}
async function validateApk(p){const z=await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true});if(!z.files['AndroidManifest.xml']||!z.files['classes.dex'])throw Error('Generated APK failed structural validation.')}
async function validateDocx(p){const z=await JSZip.loadAsync(await fs.readFile(p),{checkCRC32:true});if(!z.files['[Content_Types].xml']||!z.files['word/document.xml'])throw Error('Invalid DOCX package.')}
module.exports={convert};
